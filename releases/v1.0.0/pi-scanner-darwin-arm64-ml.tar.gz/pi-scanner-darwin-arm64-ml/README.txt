PI Scanner v1.0.0 - Native Build with ML Support

This build includes machine learning support for enhanced PI detection.

Requirements:
- ONNX Runtime (optional, for ML features)
- libtokenizers.a is included

Usage:
  ./pi-scanner scan --repo https://github.com/org/repo

For more information:
  ./pi-scanner help
